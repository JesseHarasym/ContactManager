﻿CREATE TABLE [dbo].[Groups]
(
	[GroupID] INT NOT NULL IDENTITY(1, 1) PRIMARY KEY, 
    [GroupName] NVARCHAR(50) NULL, 
    [ContactCards] VARBINARY(MAX) NULL
)
